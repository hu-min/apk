package com.cszwk.production

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 最小可用的网址打包 APK：
 *  - 加载 https://xt.cszwk.com/
 *  - 正确实现 onShowFileChooser，处理 <input capture> 调起相机（isCaptureEnabled）
 *  - 声明并授权 CAMERA 权限；onPermissionRequest 授权 getUserMedia 兜底
 *  - 站点保持纯 Web，无需任何改动，capture 属性直接生效
 *
 * 如需改网址：修改下方的 BASE_URL。
 * 如需改包名：改 AndroidManifest 的 package / applicationId 以及本文件 package 与 AUTHORITY。
 */
class MainActivity : AppCompatActivity() {

    // ===== 可配置项 =====
    private val BASE_URL = "https://xt.cszwk.com/"
    private val AUTHORITY = "com.cszwk.production.fileprovider"
    // ====================

    private val REQ_CHOOSER = 100
    private val REQ_CAMERA_PERM = 101

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        setupWebView()

        // 启动时申请相机权限，保证首次进入即可拍照
        if (!hasCameraPermission()) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA), REQ_CAMERA_PERM
            )
        }
    }

    private fun setupWebView() {
        val ws: WebSettings = webView.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true
        ws.allowFileAccess = true
        ws.allowContentAccess = true
        // 站点若混用 http 子资源，放开混合内容（按需要保留）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ws.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        ws.loadWithOverviewMode = true
        ws.useWideViewPort = true
        ws.mediaPlaybackRequiresUserGesture = false // 允许 getUserMedia 等需用户手势外的媒体

        webView.webViewClient = object : WebViewClient() {
            // 站内导航保持在 WebView 内
            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean = false
        }

        webView.webChromeClient = object : WebChromeClient() {

            // 授权网页 getUserMedia（摄像头）请求
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }

            // 文件选择 / 拍照的核心回调
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // 先取消上一次未完成的回调，避免重复点击无反应
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val params = fileChooserParams ?: run {
                    this@MainActivity.filePathCallback = null
                    return false
                }

                val capture = params.isCaptureEnabled
                val acceptTypes = params.acceptTypes?.toList().orEmpty()
                val wantsImage = capture || acceptTypes.any { it.startsWith("image") }

                // 基础文件选择器
                val contentIntent = if (capture) {
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                } else {
                    params.createIntent()
                }

                // 需要图片且已有相机权限 → 额外加入“拍照”入口
                val extraIntents = ArrayList<Intent>()
                if (wantsImage && hasCameraPermission()) {
                    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    val photoFile = createImageFile()
                    if (photoFile != null) {
                        cameraPhotoUri = FileProvider.getUriForFile(
                            this@MainActivity, AUTHORITY, photoFile
                        )
                        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri)
                        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                        extraIntents.add(cameraIntent)
                    }
                }

                val chooser = Intent.createChooser(contentIntent, "选择文件或拍照")
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extraIntents.toArray(arrayOf<Intent>()))

                return try {
                    startActivityForResult(chooser, REQ_CHOOSER)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }

        webView.loadUrl(BASE_URL)
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun createImageFile(): File? = try {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = File(filesDir, "captured")
        if (!dir.exists()) dir.mkdirs()
        File(dir, "JPEG_$ts.jpg")
    } catch (e: Exception) {
        null
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CHOOSER) {
            val results = if (resultCode == RESULT_OK) {
                when {
                    // 优先取系统选择器返回（选图/选文档）
                    data != null -> FileChooserParams.parseResult(resultCode, data)
                    // 否则是拍照：用我们预先写好的 EXTRA_OUTPUT 路径
                    cameraPhotoUri != null -> arrayOf(cameraPhotoUri!!)
                    else -> null
                }
            } else {
                null // 取消，必须回传 null 才能再次点击
            }
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
            cameraPhotoUri = null
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // 权限结果无需特殊处理，下次点击文件框即生效
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
