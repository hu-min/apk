# 保留原生 WebView 回调所需的类（避免混淆导致 onShowFileChooser 失效）
-keepclassmembers class * extends android.webkit.WebChromeClient {
    public *;
}
-keepattributes *Annotation*
